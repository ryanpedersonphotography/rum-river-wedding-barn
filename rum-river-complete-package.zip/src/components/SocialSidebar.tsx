export default function SocialSidebar() {
  return (
    <div className="social-sidebar">
      <a href="#">FB</a>
      <a href="#">IG</a>
      <a href="#">TW</a>
    </div>
  )
}